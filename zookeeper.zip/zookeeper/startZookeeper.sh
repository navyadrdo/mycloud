#!/bin/sh
cd ./zookeeper-3.4.12
bin/zkServer.sh start conf/zoo.cfg
bin/zkServer.sh start conf/zoo1.cfg
bin/zkServer.sh start conf/zoo2.cfg

