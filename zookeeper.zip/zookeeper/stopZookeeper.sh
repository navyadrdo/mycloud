#!/bin/sh
cd ./zookeeper-3.4.12
bin/zkServer.sh stop conf/zoo.cfg
bin/zkServer.sh stop conf/zoo1.cfg
bin/zkServer.sh stop conf/zoo2.cfg

